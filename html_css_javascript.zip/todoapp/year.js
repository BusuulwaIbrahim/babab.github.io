const yearInput = document.getElementById("year");
const btn = document.getElementById("btn");
const result = document.getElementById("result");

btn.addEventListener("click", function () {
  const yearValue = yearInput.value.trim();

  if (isNaN(yearValue)) {
    alert("Please prove numbers only!");
    return;
  }

  const currentYear = 2023;

  if (yearValue > currentYear) {
    alert("Please provide a year less than 2023");
    return
  }

  const age = currentYear - yearValue;
  result.textContent = "You are " + age + " years old";
});
