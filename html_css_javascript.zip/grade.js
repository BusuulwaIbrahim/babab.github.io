// calculate grades
function calculateGrades(mark) {
  let grade;

  if (mark >= 90) {
    grade = "D1";
  } else if (mark >= 80 && mark < 90) {
    grade = "D2";

    // C3, C4, P5, P6
  } else {
    grade = "F9";
  }

  return grade;
}

const markInput = document.getElementById("grade");
const btn = document.getElementById("btn");
const markResult = document.getElementById("result");

btn.addEventListener("click", function (e) {
  let mark = markInput.value;

  if (isNaN(mark)) {
    alert("Please enter numbers only");
    return;
  }

  const grade = calculateGrades(parseInt(mark));

  markResult.textContent = "Your grade is: " + grade;
});
