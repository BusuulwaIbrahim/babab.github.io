document.addEventListener("DOMContentLoaded", function () {
  // Initialize task input, add task button, task list, no task message, and task error elements
  const taskInput = document.getElementById("task");
  const addTaskButton = document.getElementById("addTask");
  const taskList = document.getElementById("taskList");
  const noTask = document.getElementById("noTask");
  const taskError = document.querySelector(".error");

  // Check if there are any existing tasks in the task list
  checkTasks();

  // Add event listener to the add task button to handle task addition
  addTaskButton.addEventListener("click", addTask);

  function addTask() {
    // Get the task text from the task input field and trim any leading or trailing whitespace
    const taskText = taskInput.value.trim();

    // Check if the task text is not empty
    if (taskText) {
      // Create a new list item element to represent the task
      const listItem = document.createElement("li");

      // Set the list item's inner HTML to include the task text and a delete button
      listItem.innerHTML = `
          <span>${taskText}</span>
          <button class="delete">Delete</button>
        `;

      // Append the newly created list item to the task list
      taskList.appendChild(listItem);

      // Clear the task input field
      taskInput.value = "";

      // Add event listeners to the delete button and the list item itself
      const deleteButton = listItem.querySelector("button.delete");
      deleteButton.addEventListener("click", deleteTask);
      listItem.addEventListener("click", toggleComplete);

      // Hide the task error message
      taskError.style.display = "none";

      // Check if there are any tasks in the task list
        checkTasks();
    } else {
      // Display the task error message for 2 seconds and then hide it
      taskError.style.display = "block";
      setTimeout(function () {
        taskError.style.display = "none";
      }, 2000);
    }
  }

  function deleteTask(event) {
    // Get the list item element that contains the delete button that was clicked
    const listItem = event.target.parentElement;

    // Remove the list item element from the task list
    taskList.removeChild(listItem);

    // Check if there are any tasks in the task list
    checkTasks();
  }

  function toggleComplete(event) {
    // Get the list item element that was clicked
    const listItem = event.target;

    // Toggle the 'completed' class on the list item element, which will change its styling
    listItem.classList.toggle("completed");
  }

  function checkTasks() {
    // Check if there are any child elements (task list items) in the task list
    if (document.querySelectorAll("#taskList li").length > 0) {
      // If there are, hide the no task message
      noTask.style.display = "none";
    } else {
      // If there aren't, show the no task message
      noTask.style.display = "block";
    }
  }
});
