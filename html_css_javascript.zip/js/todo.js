const taskInput = document.getElementById("task");
const taskBtn = document.getElementById("add");
const taskList = document.getElementById("tasklist");

taskBtn.addEventListener("click", function (event) {
  const taskText = taskInput.value.trim();

  if (taskText.length === 0) {
    alert("Please provide a task");
    return;
  }

  const listItem = document.createElement("li");
  listItem.textContent = taskText;
  taskList.appendChild(listItem);

  listItem.innerHTML = `<button>Delete</button>`

  taskInput.value = "";
});

taskInput.addEventListener("keydown", function (event) {
  if (event.key == "Enter") {
    taskBtn.click();
  }
});
