let age = 20;

// if ... else
if (age > 40) {
  console.log("You are old");
} else {
  console.log("You are not old yet!");
}

// Nested IF statement
// if ... else if ... else if ... else
const masterPassword = "foobar";
let password = "abc84579";
let errorMessage;

const input = document.getElementById("password");

input.addEventListener("keyup", function (e) {
  const value = e.target.value;
  const error = document.getElementById("error");

  if (value.length < 5) {
    errorMessage = "Password is too short!";
    error.innerText = errorMessage;
  } else if (value === masterPassword) {
    errorMessage = null;
    error.style.color = "green";
    error.innerText = "Password is correct 🎉";
  } else {
    errorMessage = "Incorrect password";
    error.style.color = "red"
    error.innerText = errorMessage;
  }
});
