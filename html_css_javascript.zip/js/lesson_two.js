const fruits = ["Apple", "Mango", "PawPaw"];

// for const item of sequence

for (const item of fruits) {
  console.log(item);
}

for (let i = 0; i < fruits.length; i++) {
  console.log(fruits[i]);
}

let j = 0;

while (j < fruits.length) {
  console.log(fruits[j]);
  j++;
}

// Using map

fruits.map(fruit => {
	console.log(fruit)
})


